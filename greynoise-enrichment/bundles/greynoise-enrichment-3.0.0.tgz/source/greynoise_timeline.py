import requests
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Optional, Any


# Map API field names to display names
FIELD_MAPPING = {
    "destination_port": "Ports",
    "http_path": "Web Paths",
    "http_user_agent": "User Agents",
    "source_asn": "ASN",
    "source_org": "Organization",
    "source_rdns": "rDNS",
    "tag_ids": "Tags",
    "classification": "Classification"
}

DEFAULT_FIELDS = [
    "destination_port", "http_path", "http_user_agent", 
    "source_asn", "source_org", "source_rdns", 
    "tag_ids", "classification"
]


def fetch_tags_mapping(
    api_key: str, 
    base_url: str = "https://api.greynoise.io/v3",
    user_agent: str = "greynoise-timeline-function"
) -> Dict[str, str]:
    """
    Fetch tag ID to name mapping from GreyNoise API.
    
    Args:
        api_key: GreyNoise API key
        base_url: Base API URL
        user_agent: User-Agent string for API requests (default: "greynoise-timeline-function")
        
    Returns:
        Dictionary mapping tag IDs to tag names
    """
    headers = {
        "Accept": "application/json",
        "key": api_key,
        "User-Agent": user_agent
    }
    tags_url = f"{base_url}/tags"
    
    try:
        response = requests.get(tags_url, headers=headers, timeout=10)
        response.raise_for_status()
        tags_data = response.json()
        
        # Handle different possible response structures
        if isinstance(tags_data, dict):
            tags_list = tags_data.get('tags') or tags_data.get('data') or tags_data.get('results') or []
        elif isinstance(tags_data, list):
            tags_list = tags_data
        else:
            tags_list = []
        
        return {tag.get('id'): tag.get('name') for tag in tags_list if isinstance(tag, dict)}
    except Exception as e:
        print(f"Warning: Failed to fetch tags mapping: {e}")
        return {}


def fetch_field_timeline(
    ip: str, 
    field: str, 
    api_key: str, 
    days: int = 30, 
    granularity: str = "1d",
    base_url: str = "https://api.greynoise.io/v3",
    user_agent: str = "greynoise-timeline-function"
) -> Optional[Dict[str, Any]]:
    """
    Fetch timeline data for a specific field.
    
    Args:
        ip: IP address to query
        field: Field name to fetch
        api_key: GreyNoise API key
        days: Number of days of history
        granularity: Time granularity (e.g., '1d', '1h')
        base_url: Base API URL
        user_agent: User-Agent string for API requests (default: "greynoise-timeline-function")
        
    Returns:
        API response data or None on error
    """
    headers = {
        "Accept": "application/json",
        "key": api_key,
        "User-Agent": user_agent
    }
    url = f"{base_url}/noise/ips/{ip}/timeline?days={days}&field={field}&granularity={granularity}"
    
    try:
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        print(f"Warning: Failed to fetch {field}: {e}")
        return None


def process_field_data(
    data: Dict[str, Any], 
    field: str, 
    tags_dict: Dict[str, str],
    field_mapping: Dict[str, str]
) -> Dict[str, List[str]]:
    """
    Process timeline data for a single field and organize by timestamp.
    
    Args:
        data: API response data
        field: Field name being processed
        tags_dict: Tag ID to name mapping
        field_mapping: API field to display name mapping
        
    Returns:
        Dictionary mapping timestamps to lists of label values
    """
    field_data = defaultdict(list)
    
    if not data:
        return field_data
    
    # Extract the field name from metadata and map to display name
    api_field_name = data.get('metadata', {}).get('field', field)
    display_field_name = field_mapping.get(api_field_name, api_field_name)
    
    # Process each result entry
    for entry in data.get('results', []):
        timestamp = entry.get('timestamp')
        label = entry.get('label')
        
        if timestamp and label:
            # Replace tag IDs with names if applicable
            if api_field_name == 'tag_ids' and label in tags_dict:
                label = tags_dict[label]
            
            field_data[timestamp].append((display_field_name, label))
    
    return field_data


def get_greynoise_timeline(
    ip: str,
    api_key: str,
    fields: Optional[List[str]] = None,
    days: int = 30,
    granularity: str = "1d",
    max_workers: int = 5,
    base_url: str = "https://api.greynoise.io/v3",
    user_agent: str = "greynoise-timeline-function"
) -> List[Dict[str, Any]]:
    """
    Fetch and consolidate GreyNoise timeline data for multiple fields.
    
    Args:
        ip: IP address to query
        api_key: GreyNoise API key
        fields: List of fields to fetch (uses defaults if None)
        days: Number of days of history (default: 30)
        granularity: Time granularity (default: '1d')
        max_workers: Maximum number of concurrent API requests (default: 5)
        base_url: Base API URL (default: GreyNoise v3 API)
        user_agent: User-Agent string for API requests (default: "greynoise-timeline-function")
        
    Returns:
        List of consolidated timeline entries sorted by date
    """
    if fields is None:
        fields = DEFAULT_FIELDS
    
    # Fetch tags mapping
    tags_dict = fetch_tags_mapping(api_key, base_url, user_agent)
    
    # Dictionary to store consolidated data by timestamp
    consolidated_data = defaultdict(dict)
    
    # Fetch all field timelines in parallel
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all API requests
        future_to_field = {
            executor.submit(
                fetch_field_timeline, 
                ip, field, api_key, days, granularity, base_url, user_agent
            ): field 
            for field in fields
        }
        
        # Process results as they complete
        for future in as_completed(future_to_field):
            field = future_to_field[future]
            try:
                data = future.result()
                if data:
                    # Process field data
                    field_data = process_field_data(data, field, tags_dict, FIELD_MAPPING)
                    
                    # Merge into consolidated data
                    for timestamp, entries in field_data.items():
                        for display_name, label in entries:
                            if display_name not in consolidated_data[timestamp]:
                                consolidated_data[timestamp][display_name] = []
                            consolidated_data[timestamp][display_name].append(label)
            except Exception as e:
                print(f"Error processing {field}: {e}")
    
    # Convert to sorted list
    consolidated_list = []
    for timestamp in sorted(consolidated_data.keys()):
        entry = {'Date': timestamp}
        entry.update(consolidated_data[timestamp])
        consolidated_list.append(entry)
    
    return consolidated_list


# Example usage
if __name__ == "__main__":
    api_key = "91c2b4084abb95fe4eecb87bb9bc503877df49c064d8de9fe16dc306e638f052"
    ip_address = "210.16.184.165"
    
    timeline_data = get_greynoise_timeline(
        ip=ip_address,
        api_key=api_key,
        days=30,
        granularity="1d",
        max_workers=8,
        user_agent="greynoise-timeline-test/1.0"
    )
    
    print(timeline_data)

