import os
import sys

import requests
from AnomaliTransform import AnomaliTransform, EntityTypes

api_base = "https://api.greynoise.io/"
api_key = None
api_type = "enterprise"

VERSION = "3.0.0"
USER_AGENT = "greynoise-anomali-transform-" + VERSION  

def searchiptransform(at, search_string):  # noqa: C901
    try:
        response = requests.get(
            api_base + "v3/ip/" + search_string,
            headers={
                "Accept": "application/json",
                "key": api_key,
                "User-Agent": USER_AGENT,
            },
        )
        response_json = response.json()

        if response.status_code == 200 :
            if response_json.get("internet_scanner_intelligence", {}).get("found"):
                at.addEntity(EntityTypes.Phrase, "%s" % "Internet Noise")
            if response_json.get("business_service_intelligence", {}).get("found"):
                at.addEntity(EntityTypes.Phrase, "%s" % "Common Business Service")
            actor = response_json.get("internet_scanner_intelligence", {}).get("actor", "unknown")
            if actor and actor != "unknown":
                at.addEntity(EntityTypes.Phrase, "%s" % "actor: " + actor)
            bs_provider = response_json.get("business_service_intelligence", {}).get("name", "unknown")
            if bs_provider and bs_provider != "unknown":
                at.addEntity(EntityTypes.Phrase, "%s" % "business service: " + bs_provider)
            if response_json.get("internet_scanner_intelligence", {}).get("classification", "") and response_json.get("internet_scanner_intelligence", {}).get("classification", "") != "":
                at.addEntity(
                    EntityTypes.Phrase,
                    "%s" % "classification: " + response_json.get("internet_scanner_intelligence", {}).get("classification", ""),
                )
            asn_value = response_json.get("internet_scanner_intelligence", {}).get("metadata", {}).get("asn")
            if asn_value.startswith("AS"):
                asn_value = asn_value[2:]
            if asn_value and asn_value != "":
                at.addEntity(EntityTypes.AS, "%s" % asn_value)
            if response_json.get("internet_scanner_intelligence", {}).get("vpn", False) and response_json.get("internet_scanner_intelligence", {}).get("vpn", "False") == "True":
                at.addEntity(EntityTypes.Phrase, "%s" % "Known VPN Service: " + response_json.get("internet_scanner_intelligence", {}).get("vpn_service", "Unidentified"))
            if response_json.get("internet_scanner_intelligence", {}).get("tor", False) and response_json.get("internet_scanner_intelligence", {}).get("tor", "False") == "True":
                at.addEntity(EntityTypes.Phrase, "%s" % "Known Tor Exit Node")
        elif response.status_code == 404:
            at.addEntity(EntityTypes.Phrase, "%s" % "Not Internet Noise")
        elif response.status_code == 400:
            at.addException("Invalid IP Address, please verify")
        elif response.status_code == 401:
            at.addException("API Key is Missing, Expired or Incorrect, please verify")
        elif response.status_code == 429:
            at.addException("API Rate-Limit Reached, Please try again tomorrow.")
        elif response.status_code == 500:
            at.addException("An error occurred with the GreyNoise API, please contact GreyNoise for assistance.")
    except:  # noqa E722
        at.addException(
            "Search IP Unknown Error:%sType: %s%sValue:%s"
            % (os.linesep, sys.exc_info()[0], os.linesep, sys.exc_info()[1])
        )
    return at


functions = {"Search IP": searchiptransform}

if __name__ == "__main__":
    at = AnomaliTransform()
    at.parseArguments()
    transform_name = at.getTransformName()
    entity_value = at.getEntityValue()
    api_key = at.getCredentialValue("api_key")

    functions[transform_name](at, entity_value)
    at.returnOutput()
